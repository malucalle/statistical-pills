################################################################
#
# ESQUEMA D'ANÀLISI DE DADES AMB R, by Malu Calle 
#
################################################################

################################################################################
#
# PREPARACIÓ DE LES DADES 
#
################################################################################

# Especificar la carpeta de treball directament des de RStudio:
#..................................................................

# Session -> Set working directory -> choose directory


# Importar les dades a R directament des de RStudio 
#..............................................

# File -> Import Dataset

    # -> From Excel... -> Browse   (carregueu el fitxer "nadons.xlsx")
    # Comprovar que les variables numèriques s'importen com a numèriques o double  


# També es pot fer amb aquest codi:

# install.packages("readxl")
# library(readxl)
# nadons <- read_excel("nadons.xlsx")

# Mirar la taula de dades que hem carregat
#.................................................

View(***)

# clicar sobre el nom de la taula a la finestra "Environment" i comprovar que les dades s'han carregat bé

# Canviem el nom de la taula a "data"

data<-***

rm(***)  # eliminem (remove) la taula nadons

# Mirar l'estructura de les dades i el tipus de cada variable
#.........................................................

str(***)

# Veiem que totes les variables s'han importat com a numèriques (num) o caràcter (chr) 

# Fer un resum numèric conjunt de totes les variables 
#......................................................

***(data)

# Com es pot veure el resum de les dades categòriques no es adequat i cal preparar-les per l'anàlisi

# Preparar les dades categòriques amb la funció factor()
# ..........................................................

# Variables caràcter (chr) 
data$prematur<-***(data$prematur)   
data$nado_sexe<-factor(***$nado_sexe)
data$mare_fumadora<-factor(data$***)

# Variables numèriques (num) que en realitat són categòriques: 
# Cal especificar què representa cada valor: 
data$edat_mare<-factor(data$edat_mare, levels = c(***,***,***), labels = c("<=30", "30-40", ">40"))
data$nado_baix_pes<-factor(data$nado_baix_pes, levels = c(***,***), labels = c("no", "si"))

# Tornem a fer un resum numèric conjunt de totes les variables 
#......................................................

summary(***)

# Gràfics amb R
#.....................................................

# Utilitzarem la llibreria **ggpubr** que permet fer gràfics més interessants que els que es poden fer amb les funcions bàsiques d'R. 
# 
# Podeu veure exemples dels gràfics més importants en aquest tutorial: https://uvic-omics.github.io/statistical_pills/nice-plots-with-r.html

#install.packages("ggpubr")  # instal·lar la llibreria a l'ordinador, el nom ha d'estar entre comentes. Només s'ha de fer un cop

library(***)   # activar la llibreria. S'ha de fer cada cop que s'engega R


# Histogrames de les variables numèriques
#............................................................


gg***(data, x="setmanes_gestacio",
            bins = 20, 
            col="aquamarine2", fill="aquamarine2")


# Podeu representar totes les variables numèriques de cop:

p<-gg***(data, 
     x=c("setmanes_gestacio","nombre_visites","nado_pes","mare_pes_ini","mare_pes_fi"),
     bins = 20)
p

# Boxplots de les variables numèriques
#............................................................

p<-gg***(data, y="setmanes_gestacio", color = "blue")
p

# Diagrames de barres de les variables categòriques
#............................................................

***(data$edat_mare)   #taula de freqüències
***.table(table(data$edat_mare))    #taula de proporcions (freq. relatives)

***(table(data$edat_mare))   #Gràfic de barres de freq
***(prop.table(table(data$edat_mare)))   #Gràfic de barres de proporcions

#Variables comptatge (recompte)
#####################################################################

# Mirar si alguna de les variables són comptatges (recomptes) perquè requeriran una atenció especial.
# 
# Les variables comptatges es poden analitzar com si fossin numèriques o com categòriques i mirar quin dels dos anàlisis ens aporta més informació sobre la variable:
#   
#   La variable “nombre_visites” és un recompte. La podem analitzar segons una variable numèrica:


***(data$nombre_visites)  #resum numèric nombre visites

gg***(data, x="nombre_visites",    #histograma
            bins = 20, 
            color = "coral1", fill = "coral1")  

# Podem subdividir el nombre de visites en 2 categories: "<= 4" i "superiors a 4"

data$visites_cat2<-cut(data$nombre_visites, c(0,4,20))

***(data$visites_cat2)    #taula de freq

***(table(data$visites_cat2))   #taula de proporcions

***(table(data$visites_cat2),   #gràfic de barres
        col=c("aquamarine2", "coral1"))

# També podem subdividir el nombre de visites en 3 categories: "<=2", ">2 i <=4" i ">4"

data$visites_cat3<-cut(data$nombre_visites, c(0,2,4,20))

***(data$visites_cat3)      #taula de freq

***(table(data$visites_cat3))    #taula de proporcions

***(table(data$visites_cat3),           #gràfic de barres
        col=c("aquamarine2", "coral1","darkturquoise"))


# Resum dels resultats obtinguts fins al moment: Informe descripció inicial de les dades
#.............................................................

# És molt important tenir una bona descripció inicial de les dades que analitzarem.  
# És recomanable fer un informe d'aquesta descripció inicial, tot i que aquesta part segurament no caldrà 
# incloure-la a l'informe final (es pot afegir com a annex).
# En aquesta fase es poden detectar possibles valors anòmals i decidir què fer amb ells.
# En general, eliminar valors no és una opció acceptable, llevat que es tracti de valors extremadament diferents de la majoria 
# i que distorsionen molt els resultats.
# Si es decideix eliminar algun valor cal fer-ho de manera transparent i, en tot cas, informar d'aquest fet. 


##############################################################################
#
# ANÀLISI DE LES DADES
#
##############################################################################

# Concretar i prioritzar els objectius.
# Identificar les variables involucrades en cada objectiu
#.........................................

######################################################################
# Anàlisi relació dues var. numèriques
######################################################################

gg***(data, x = "setmanes_gestacio", y = "nado_pes",             #scatter plot
          add = "reg.line",                                      # regression line
          conf.int = TRUE,                                       # confidence interval
          add.params = list(color = "coral1", fill = "bisque")   # color
)+
  stat_cor(method = "pearson")      # correlation coefficient


######################################################################
# Anàlisi relació var. numèrica i var.categòria
######################################################################

# Histograma de la var. numèrica en funció de la categòrica:
#.............................................................

# Exemple: "setmanes_gestacio" (numèrica) i "nado_pes_baix" (categòrica)

gg***(data, 
            x=***,                   # x = numèrica
            color="nado_baix_pes",   # color = categòrica
            add = "mean",
            bins = 20)


# Boxplot de la var. numèrica en funció de la categòrica:
#.........................................................

# Exemple: "setmanes_gestacio" (numèrica) i "nado_pes_baix" (categòrica)

p<-ggboxplot(data, 
            y=***,                # y = numèrica
            x=***,                # x = categòrica
            color = "nado_baix_pes",
            )

p

# Resum de la variable numèrica en funció de les categories  
# ..................................................................

# amb la funció tapply():

tapply(data$***, data$***, summary)

# o bé amb la funció desc_statby() de ggpubr 

desc_statby(***,"setmanes_gestacio", "nado_baix_pes") 


# Proves d'hipòtesis d'igualtat de mitjanes
#...........................................

# Si les dades en cada categoria són normals (shapiro test):
  # apliquem t.test (2 categories) o anova (> 2 categories)

# Si les dades en cada categoria no són normals (shapiro test):
  # apliquem wilcoxon test (2 categories) o Kruskal-wallis (> 2 categories)

#Exemple1: Analitzar la possible relació entre el nombre de setmanes de gestació i que el nadó tingui baix pes o no?
  
#  “setmanes_gestacio” (numèrica) i “nado_pes_baix” (categòrica)

tapply(data$***, data$***, function(x) shapiro.test(x))


***(data$setmanes_gestacio~data$nado_baix_pes)


# Exemple2: Analitzar la possible relació entre el pes inicial de la mare i que el nadó tingui baix pes o no?
   
#   “mare_pes_ini” (numèrica) i “nado_pes_baix” (categòrica):
  

tapply(data$***, data$***, function(x) shapiro.test(x))

***(data$mare_pes_ini~data$nado_baix_pes)

***(data$mare_pes_ini~data$nado_baix_pes, var.equal=***)


# Exemple 3: Analitzar la possible relació entre l’edat de la mare i el pes del nadó
  
#   “edat_mare” (categòrica) i “nado_pes” (numèrica)
#....................................................................


tapply(data$***, data$***, function(x) shapiro.test(x))

# Comprovem la igualtat de variàncies amb el bptest

#install.packages("lmtest")

***(lmtest)

bptest(lm(data$nado_pes ~data$edat_mare),studentize = FALSE)

# Apliquem ANOVA:

summary(***(data$nado_pes~data$edat_mare))

# Si l'ANOVA hagués sortit significatiu aplicaríem el test de Tukey

TukeyHSD(aov(data$nado_pes~data$***))

# Exemple 4: Analitzar la possible relació entre l’edat de la mare i el nombre de setmanes de gestació?
 
#   “edat_mare” (categòrica) i “setmanes_gestacio” (numèrica)

#....................................................................

tapply(data$***, data$***, function(x) shapiro.test(x))

***(data$setmanes_gestacio~data$edat_mare)



######################################################################
# Anàlisi relació dues var. categòriques
######################################################################

freq<-***(data$mare_fumadora, data$nado_baix_pes)   #taula freq

freqbyrow<-***(table(data$mare_fumadora, data$nado_baix_pes),***) #taula freq per files

freqbyrow<-as.data.frame(freqbyrow)                  # transform the table into a data frame
freqbyrow

colnames(freqbyrow)<-c("mare_fumadora","nado_baix_pes","Freq")
freqbyrow

ggbarplot(freqbyrow, x=***, y="Freq",       # x = variable that defines the rows of the table     
          color = "nado_baix_pes",                            
          label = TRUE,
          lab.nb.digits = 2)                    # number of digits for the proportions

#Test xi-quadrat

***(freq)

#Test de Fisher per taules 2x2

fisher.test(freq)

#Mesura d'associació entre dues variables categòriques

library(rcompanion)
cramerV(data$mare_fumadora, data$nado_baix_pes, bias.correct = T)



########################################################################################################

# MODELS DE REGRESSIÓ

#################################################################################################


#Els models de regressió són útils per estudiar la relació d’una o més variables sobre una variable d’interès (variable resposta).

# REGRESSIO LINEAL
#...............................................................................

# El model de regressió lineal s’utilitza quan la variable resposta és numèrica (contínua):
   
#   Exemple: Quin és l’efecte de l’edat de la mare sobre el pes del nadó en funció de si fuma o no fuma?
   
#   y = “nado_pes” (numèrica)
 
# x1 = “edat_mare” (categòrica), x2 = “mare_fumadora” (categòrica), x3= mare_pes_ini (numèrica)


model1<-***(nado_pes~mare_fumadora+edat_mare+ mare_pes_ini, data = ***)
summary(model1)

#Cal comprovar que es compleixen els requisits de la regressió lineal:
  
#  Normalitat dels residus:
 
 ***(residuals(model1))

#Els residus estan centrats al voltant del zero:

   plot(residuals(***))
  abline(a=0, b=0)

  
# REGRESSIÓ LOGÍSTICA
#...........................................................

#  El model de regressió logística s’utilitza quan la variable resposta és binària (categòrica, amb dues categories):
    
#  Exemple: Quin és l’efecte de l’edat de la mare en el risc que el nen tingui baix pes en funció de si la mare fuma o no fuma?
    
#  y = “nado_pes_baix” (binària)
  
#  x1=“edat_mare” (categòrica), x2=“mare_fumadora” (categòrica)

model2<-glm(nado_baix_pes~mare_fumadora+edat_mare, data = ***, family = "binomial")
summary(***)

# SELECCIÓ DE VARIABLES: STEP-WISE REGRESSION

# La selecció de variables s’utilitza per identificar quines variables estan més relacionades amb la variable d’interès.

# Exemple: Quines variables estan relacionades amb el pes del nadó?
   
#   L’objectiu és identificar quines variables estan realment relacionades amb el pes del nadó i quines es poden eliminar del model. Afegirem en l’anàlisi l’augment de pes de la mare durant l’embaràç:
  
  data$augment_pes<-data$mare_pes_fi-data$mare_pes_ini

model3<-lm(nado_pes~., data = data[, c(2,3,7,8,9,14)])
summary(***)

#Selecció de variables (step-wise regression)

step(***)

#Resum del millor model

summary(step(***))